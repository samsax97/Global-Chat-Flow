package com.globalchatflow.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance().reference }
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (auth.currentUser != null) showChat() else showLogin()
    }

    private fun showLogin() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(48,80,48,40) }
        val title=TextView(this).apply { text="Global Chat Flow"; textSize=32f; setTextColor(0xFF0E8F4F.toInt()) }
        val sub=TextView(this).apply { text="Connect the world. One chat at a time."; textSize=16f; setPadding(0,8,0,40) }
        email=EditText(this).apply { hint="Email"; inputType=33 }
        password=EditText(this).apply { hint="Password"; inputType=129 }
        val login=Button(this).apply { text="Log In" }
        val signup=Button(this).apply { text="Create Account" }
        status=TextView(this)
        box.addView(title); box.addView(sub); box.addView(email); box.addView(password); box.addView(login); box.addView(signup); box.addView(status)
        setContentView(box)
        login.setOnClickListener { signIn() }
        signup.setOnClickListener { createAccount() }
    }

    private fun createAccount() {
        val e=email.text.toString().trim(); val p=password.text.toString()
        if(e.isEmpty() || p.length<6){ status.text="Enter a valid email and password (6+ characters)."; return }
        auth.createUserWithEmailAndPassword(e,p).addOnCompleteListener {
            if(it.isSuccessful){ db.child("users").child(auth.uid!!).child("email").setValue(e); showChat() }
            else status.text=it.exception?.message ?: "Sign-up failed"
        }
    }
    private fun signIn() {
        auth.signInWithEmailAndPassword(email.text.toString().trim(),password.text.toString()).addOnCompleteListener {
            if(it.isSuccessful) showChat() else status.text=it.exception?.message ?: "Login failed"
        }
    }
    private fun showChat() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,50,32,24) }
        val title=TextView(this).apply { text="Global Chat Flow"; textSize=28f; setTextColor(0xFF0E8F4F.toInt()) }
        val info=TextView(this).apply { text="You are signed in.\n\nBasic chat foundation is ready."; textSize=18f; setPadding(0,30,0,30) }
        val message=EditText(this).apply { hint="Type a message" }
        val send=Button(this).apply { text="Send" }
        val logout=Button(this).apply { text="Log Out" }
        box.addView(title); box.addView(info); box.addView(message); box.addView(send); box.addView(logout)
        setContentView(box)
        send.setOnClickListener {
            val text=message.text.toString().trim()
            if(text.isNotEmpty()){ db.child("messages").push().setValue(mapOf("uid" to auth.uid, "text" to text)); message.text.clear(); Toast.makeText(this,"Message saved",Toast.LENGTH_SHORT).show() }
        }
        logout.setOnClickListener { auth.signOut(); showLogin() }
    }
}
